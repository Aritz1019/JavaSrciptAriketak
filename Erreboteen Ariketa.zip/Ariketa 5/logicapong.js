//Variables globales
var bucle;
var velocidad = 10;
var canvas = document.getElementById("canvas");
var areaW = canvas.width;
var areaH = canvas.height;
var ctx = canvas.getContext("2d");
//Clases
class Base {
	choque(obj){
		if(this.fondo < obj.y || this.y > obj.fondo || this.derecha < obj.x || this.x > obj.derecha){
			return false;
		} else {
			return true;
		}
	}
}
class Bola extends Base {
	constructor(){
		super();
		this.t = 25;
		this.x = Math.floor(Math.random() * (areaW - this.t));
		this.y = Math.floor(Math.random() * (areaH - this.t));
		this.xdir = velocidad;
		this.ydir = velocidad;
	}
	choqueV(){
		if(this.y <= 0 || this.y >= (areaH -this.t)){
			this.ydir = -this.ydir;
		}
	}
	choqueH(){
		if(this.x <= 0 || this.x >= (areaW -this.t)) {
			this.xdir = -this.xdir;
		}
	}
	mover(){
		this.x+=this.xdir;
		this.y+=this.ydir;
		this.choqueV();
		this.choqueH();
	}
	dibujar(){
		ctx.fillRect(this.x, this.y, this.t, this.t);
	}
}


//objetos
var bola = new Bola();
var colores= [ 
'#FF0000',
'#0000FF',
'#00FF00',
];




//funciones globales
function dibujar(colores){
	ctx.clearRect(0,0,areaW, areaH);
	bola.dibujar();
	
}
function frame(){
	bola.mover();
	dibujar(colores);
	bucle = requestAnimationFrame(frame);
}
function iniciar(){
	var modal = document.getElementById("modal");
	modal.style.display = "none";
	frame();
}

